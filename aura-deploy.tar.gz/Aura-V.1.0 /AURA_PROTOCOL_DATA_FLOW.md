# 🔄 Aura Protocol - Complete Data Flow

## 📊 System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        AURA PROTOCOL                             │
│                  Universal Trust Layer                           │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   ┌────▼────┐          ┌────▼────┐          ┌────▼────┐
   │Frontend │          │ Backend │          │On-Chain │
   │  Layer  │◄────────►│  Layer  │◄────────►│  Layer  │
   └─────────┘          └─────────┘          └─────────┘
        │                     │                     │
   React App            FastAPI Server      Smart Contracts
   Port 3030            Port 8080           Polygon Amoy
```

---

## 🎯 Core Features Data Flow

### 1. Proof of Humanity (PoH) Flow

```
User Journey:
┌──────────────────────────────────────────────────────────────┐
│ 1. User connects wallet (MetaMask)                          │
│    Frontend → WalletContext → Web3 Provider                 │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 2. User initiates PoH verification                          │
│    Frontend → /poh page → ProofOfHumanity.js                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 3. OAuth verification (GitHub/Twitter)                      │
│    Frontend → OAuth Provider → Callback                     │
│    Backend → github_service.py / twitter_service.py         │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 4. On-chain verification                                    │
│    Backend → onchain_service.py → Alchemy API              │
│    Query: Transaction history, token balances              │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 5. Calculate PoH score                                      │
│    Backend → poh_routes.py → Scoring algorithm             │
│    Formula: GitHub (35%) + Twitter (25%) + On-chain (40%)  │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 6. Generate ZK proof                                        │
│    Backend → polygon_id_service.py → ZK proof generation   │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 7. Mint ZK-ID Badge (On-Chain)                             │
│    Backend → blockchain.py → SimpleZKBadge contract        │
│    Contract: 0x9e6343BB504Af8a39DB516d61c4Aa0aF36c54678    │
│    Function: issueBadge(recipient, badgeType, zkProofHash) │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 8. Store proof on-chain                                     │
│    Backend → ProofRegistry contract                         │
│    Contract: 0x296DB144E62C8C826bffA4503Dc9Fbf29F25D44B    │
│    Function: registerProof(proofHash, user)                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 9. Auto-create Credit Passport                             │
│    Backend → passport_routes.py → Create passport          │
│    Trigger: After successful badge mint                    │
└──────────────────────────────────────────────────────────────┘
```


### 2. Credit Passport Flow

```
User Journey:
┌──────────────────────────────────────────────────────────────┐
│ 1. User requests Credit Passport                            │
│    Frontend → /passport page → CreditPassport.js            │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 2. Check prerequisites                                       │
│    Backend → Check PoH completion                           │
│    Backend → Check badge ownership                          │
│    Requirement: At least 1 ZK-ID badge                      │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 3. Calculate credit score                                    │
│    Backend → credit_scoring.py                              │
│    Formula: (PoH × 4) + (Badges × 50) + Bonus + Activity   │
│    Range: 0-1000                                            │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 4. Mint Credit Passport NFT (On-Chain)                      │
│    User → MetaMask → CreditPassport contract                │
│    Contract: 0x1112373c9954B9bbFd91eb21175699b609A1b551    │
│    Function: mintPassport(pohScore, badgeCount)            │
│    Type: Soulbound (non-transferable)                      │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 5. Store passport data                                       │
│    Backend → MongoDB (passports collection)                 │
│    On-Chain → CreditPassport contract storage               │
│    Data: Score, grade, risk level, timestamps               │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 6. Display passport                                          │
│    Frontend → Query passport data                           │
│    Show: Credit score, grade, badges, risk level           │
└──────────────────────────────────────────────────────────────┘
```

### 3. AI Risk Oracle Flow

```
Risk Assessment Journey:
┌──────────────────────────────────────────────────────────────┐
│ 1. User requests risk assessment                            │
│    Frontend → /oracle page → RiskOracle.js                 │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 2. Gather user data                                          │
│    Backend → Get passport data                              │
│    Backend → Get badge count                                │
│    Backend → Get on-chain activity                          │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 3. AI model processing                                       │
│    Backend → ai_risk_oracle.py                              │
│    Model: Rule-based ML (can be upgraded to trained model)  │
│    Weights:                                                 │
│      - PoH Score: 35%                                       │
│      - Badge Count: 20%                                     │
│      - On-chain Activity: 25%                               │
│      - Account Age: 10%                                     │
│      - Score Velocity: 10%                                  │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 4. Calculate risk score                                      │
│    Trust Score = Σ(feature × weight) × 100                 │
│    Risk Score = 100 - Trust Score                           │
│    Risk Level: low (0-30) / medium (31-60) / high (61-100) │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 5. Identify risk factors                                     │
│    Analyze: Low PoH, few badges, low activity, etc.        │
│    Generate: Risk factor list with severity                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 6. Generate lending recommendation                           │
│    Low risk: Max loan 1.5x, 5% APR, 110% collateral       │
│    Medium risk: Max loan 1x, 8% APR, 130% collateral      │
│    High risk: Max loan 0.5x, 12% APR, 150% collateral     │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 7. Store prediction                                          │
│    Backend → MongoDB (risk_predictions collection)          │
│    Data: Risk score, factors, timestamp, confidence        │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 8. Display results                                           │
│    Frontend → Show risk score, level, factors              │
│    UI: Color-coded (green/yellow/red)                      │
└──────────────────────────────────────────────────────────────┘
```


### 4. Proof-as-a-Service API Flow

```
External Developer Integration:
┌──────────────────────────────────────────────────────────────┐
│ 1. Developer accesses API Dashboard                         │
│    Frontend → /api page → APIDashboard.js                  │
│    Action: Connect wallet                                   │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 2. Select pricing tier                                       │
│    Options: Free (100/day), Pro (1000/day), Enterprise     │
│    Frontend → Tier selection UI                            │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 3. Generate API key                                          │
│    Frontend → POST /api/api-keys                            │
│    Backend → api_key_routes.py                             │
│    Generate: aura_sk_[32_hex_chars]                        │
│    Store: In-memory (or MongoDB for production)            │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 4. Developer uses API                                        │
│    External App → POST /api/v1/proof/generate              │
│    Header: X-API-Key: aura_sk_...                          │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 5. API key verification                                      │
│    Backend → api_key_routes.verify_api_key()               │
│    Check: Key exists, is active, not revoked               │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 6. Rate limit check                                          │
│    Backend → api_key_routes.check_rate_limit()             │
│    Check: requests_used < rate_limit                       │
│    Reject: HTTP 429 if exceeded                            │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 7. Process request                                           │
│    Backend → public_api_routes_v2.py                       │
│    Actions:                                                 │
│      - Generate proof                                       │
│      - Verify proof                                         │
│      - Query passport (on-chain)                           │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 8. Fetch on-chain data (if passport query)                  │
│    Backend → onchain_analytics.py                          │
│    Connect: Polygon Amoy RPC                               │
│    Query: CreditPassport contract                          │
│    Get: Real passport data from blockchain                 │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 9. Increment usage counter                                   │
│    Backend → api_key_routes.increment_usage()              │
│    Update: requests_used += 1                              │
│    Update: last_used timestamp                             │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 10. Return response                                          │
│     Backend → JSON response                                 │
│     Include: Data + timestamp + data_source                │
│     External App → Process response                        │
└──────────────────────────────────────────────────────────────┘
```

### 5. Analytics Dashboard Flow

```
Real-time Analytics:
┌──────────────────────────────────────────────────────────────┐
│ 1. User accesses Analytics                                  │
│    Frontend → /analytics page → Analytics.js               │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 2. Fetch on-chain analytics                                 │
│    Frontend → GET /api/analytics/onchain                   │
│    Backend → mock_routes.py                                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 3. Query blockchain data                                     │
│    Backend → onchain_analytics.py                          │
│    Connect: Polygon Amoy RPC                               │
│    Query:                                                   │
│      - SimpleZKBadge.totalSupply()                         │
│      - CreditPassport.totalSupply()                        │
│      - Current block number                                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 4. Calculate derived metrics                                │
│    Total users = Total passports (soulbound)               │
│    Verified users = Total passports × 0.7                  │
│    Verification rate = verified / total × 100              │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 5. Return analytics data                                     │
│    Backend → JSON response                                  │
│    Include: All metrics + data_source: "on-chain"         │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ 6. Display in UI                                             │
│    Frontend → Render metrics cards                         │
│    Show: Users, badges, passports, volume                  │
│    Auto-refresh: Every 30 seconds                          │
└──────────────────────────────────────────────────────────────┘
```


---

## 🔗 On-Chain Data Flow (Detailed)

### Smart Contract Interaction Pattern

```
┌─────────────────────────────────────────────────────────────┐
│                    ON-CHAIN LAYER                            │
│              Polygon Amoy Testnet (Chain ID: 80002)         │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   ┌────▼────┐          ┌────▼────┐          ┌────▼────┐
   │SimpleZK │          │ Credit  │          │  Proof  │
   │  Badge  │          │Passport │          │Registry │
   └─────────┘          └─────────┘          └─────────┘
   0x9e63...8678        0x1112...1551        0x296D...D44B
```

### 1. Badge Minting Flow (On-Chain)

```
Backend Request:
┌──────────────────────────────────────────────────────────────┐
│ Backend → blockchain.py → polygon_integration                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Connect to contract                                          │
│   Web3 → Polygon Amoy RPC                                   │
│   Contract: SimpleZKBadge (0x9e63...8678)                   │
│   ABI: Load from artifacts                                  │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Prepare transaction                                          │
│   Function: issueBadge(recipient, badgeType, zkProofHash)  │
│   Params:                                                   │
│     - recipient: User wallet address                        │
│     - badgeType: "uniqueness" / "identity" / "reputation"  │
│     - zkProofHash: Generated ZK proof hash                 │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Sign & send transaction                                      │
│   Signer: Protocol wallet (private key from .env)          │
│   Gas: Estimated automatically                              │
│   Send: Transaction to network                             │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Wait for confirmation                                        │
│   Network: Polygon Amoy                                     │
│   Confirmations: 1 block (~2 seconds)                       │
│   Receipt: Transaction hash, block number                   │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ On-chain state update                                        │
│   Contract storage:                                         │
│     - badges[tokenId] = Badge struct                        │
│     - userBadges[user].push(tokenId)                       │
│     - _tokenIds++                                           │
│   Event emitted: BadgeIssued(tokenId, recipient, type)     │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Return to backend                                            │
│   Success: Transaction hash                                 │
│   Token ID: New badge ID                                    │
│   Status: Minted & confirmed                                │
└──────────────────────────────────────────────────────────────┘
```

### 2. Passport Query Flow (On-Chain)

```
API Request:
┌──────────────────────────────────────────────────────────────┐
│ External App → POST /api/v1/passport/query                  │
│ Header: X-API-Key: aura_sk_...                             │
│ Body: { wallet_address: "0x..." }                          │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Backend authentication                                       │
│   Verify API key                                            │
│   Check rate limit                                          │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Connect to blockchain                                        │
│   Backend → onchain_analytics.py                           │
│   Web3 → Polygon Amoy RPC                                  │
│   Contract: CreditPassport (0x1112...1551)                 │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Query contract (READ operation - no gas)                    │
│   Function: getPassport(address user)                      │
│   Returns: Passport struct                                  │
│     [0] id: uint256                                         │
│     [1] owner: address                                      │
│     [2] creditScore: uint256                                │
│     [3] pohScore: uint256                                   │
│     [4] badgeCount: uint256                                 │
│     [5] onchainActivity: uint256                            │
│     [6] issuedAt: uint256                                   │
│     [7] lastUpdated: uint256                                │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Parse response                                               │
│   Extract: All passport fields                              │
│   Convert: Timestamps, scores                               │
│   Format: JSON response                                     │
└──────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────┐
│ Return to API caller                                         │
│   Response: {                                               │
│     success: true,                                          │
│     passport: { ...data },                                  │
│     data_source: "on-chain"                                 │
│   }                                                         │
└──────────────────────────────────────────────────────────────┘
```


---

## 📦 Data Storage Architecture

### 1. On-Chain Storage (Polygon Amoy)

```
SimpleZKBadge Contract:
┌─────────────────────────────────────────────────────────────┐
│ Storage Variables:                                           │
│   - _tokenIds: uint256 (counter)                           │
│   - authorizedMinters: mapping(address => bool)            │
│   - badges: mapping(uint256 => Badge)                      │
│   - userBadges: mapping(address => uint256[])              │
│                                                             │
│ Badge Struct:                                               │
│   - id: uint256                                             │
│   - owner: address                                          │
│   - badgeType: string                                       │
│   - zkProofHash: string                                     │
│   - issuedAt: uint256                                       │
└─────────────────────────────────────────────────────────────┘

CreditPassport Contract:
┌─────────────────────────────────────────────────────────────┐
│ Storage Variables:                                           │
│   - _tokenIds: uint256 (counter)                           │
│   - authorizedMinters: mapping(address => bool)            │
│   - passports: mapping(uint256 => Passport)                │
│   - userPassport: mapping(address => uint256)              │
│                                                             │
│ Passport Struct:                                            │
│   - id: uint256                                             │
│   - owner: address                                          │
│   - creditScore: uint256 (0-1000)                          │
│   - pohScore: uint256 (0-100)                              │
│   - badgeCount: uint256                                     │
│   - onchainActivity: uint256                                │
│   - issuedAt: uint256                                       │
│   - lastUpdated: uint256                                    │
└─────────────────────────────────────────────────────────────┘

ProofRegistry Contract:
┌─────────────────────────────────────────────────────────────┐
│ Storage Variables:                                           │
│   - proofs: mapping(string => Proof)                        │
│   - userProofs: mapping(address => string[])               │
│                                                             │
│ Proof Struct:                                               │
│   - proofHash: string                                       │
│   - user: address                                           │
│   - timestamp: uint256                                      │
│   - isValid: bool                                           │
└─────────────────────────────────────────────────────────────┘
```

### 2. Off-Chain Storage (Backend)

```
MongoDB Collections (Production):
┌─────────────────────────────────────────────────────────────┐
│ users:                                                       │
│   - id: string (UUID)                                       │
│   - wallet_address: string                                  │
│   - username: string                                        │
│   - email: string (optional)                                │
│   - is_verified: boolean                                    │
│   - verification_method: string                             │
│   - created_at: datetime                                    │
│                                                             │
│ badges:                                                      │
│   - id: string (UUID)                                       │
│   - user_id: string                                         │
│   - badge_type: string                                      │
│   - token_id: string                                        │
│   - metadata: object                                        │
│   - issued_at: datetime                                     │
│                                                             │
│ passports:                                                   │
│   - id: string (UUID)                                       │
│   - user_id: string                                         │
│   - wallet_address: string                                  │
│   - passport_id: string                                     │
│   - credit_score: number (0-1000)                          │
│   - poh_score: number (0-100)                              │
│   - badge_count: number                                     │
│   - grade: string                                           │
│   - risk_level: string                                      │
│   - issued_at: datetime                                     │
│   - last_updated: datetime                                  │
│                                                             │
│ api_keys:                                                    │
│   - api_key: string                                         │
│   - tier: string (free/pro/enterprise)                     │
│   - user_id: string                                         │
│   - rate_limit: number                                      │
│   - requests_used: number                                   │
│   - is_active: boolean                                      │
│   - created_at: datetime                                    │
│   - last_used: datetime                                     │
│                                                             │
│ risk_predictions:                                            │
│   - wallet_address: string                                  │
│   - prediction: object                                      │
│   - created_at: datetime                                    │
└─────────────────────────────────────────────────────────────┘

In-Memory Storage (Development):
┌─────────────────────────────────────────────────────────────┐
│ api_keys_storage: dict                                       │
│   Key: api_key (string)                                     │
│   Value: {                                                  │
│     api_key, tier, user_id, rate_limit,                    │
│     requests_used, is_active, created_at                   │
│   }                                                         │
└─────────────────────────────────────────────────────────────┘
```

### 3. Frontend State Management

```
React Context (WalletContext):
┌─────────────────────────────────────────────────────────────┐
│ State:                                                       │
│   - address: string (wallet address)                        │
│   - isConnected: boolean                                    │
│   - chainId: number                                         │
│   - provider: Web3Provider                                  │
│                                                             │
│ Functions:                                                   │
│   - connectWallet()                                         │
│   - disconnectWallet()                                      │
│   - switchNetwork()                                         │
└─────────────────────────────────────────────────────────────┘

Component State (Local):
┌─────────────────────────────────────────────────────────────┐
│ Analytics.js:                                                │
│   - analytics: object (metrics data)                        │
│   - loading: boolean                                        │
│                                                             │
│ APIDashboard.js:                                             │
│   - apiKeys: array (user's API keys)                        │
│   - selectedTier: string                                    │
│   - creating: boolean                                       │
│                                                             │
│ RiskOracle.js:                                               │
│   - prediction: object (risk assessment)                    │
│   - loading: boolean                                        │
└─────────────────────────────────────────────────────────────┘
```


---

## 🔄 Integration Points & APIs

### 1. External Service Integrations

```
GitHub OAuth:
┌─────────────────────────────────────────────────────────────┐
│ Flow: User → GitHub → Callback → Backend                    │
│ Service: github_service.py                                  │
│ Endpoints:                                                   │
│   - https://github.com/login/oauth/authorize               │
│   - https://github.com/login/oauth/access_token            │
│   - https://api.github.com/user                            │
│ Data Retrieved:                                             │
│   - Account age, repos, followers, contributions           │
│ Weight: 35% of PoH score                                    │
└─────────────────────────────────────────────────────────────┘

Twitter OAuth:
┌─────────────────────────────────────────────────────────────┐
│ Flow: User → Twitter → Callback → Backend                   │
│ Service: twitter_service.py                                 │
│ Endpoints:                                                   │
│   - https://twitter.com/i/oauth2/authorize                 │
│   - https://api.twitter.com/2/oauth2/token                 │
│   - https://api.twitter.com/2/users/me                     │
│ Data Retrieved:                                             │
│   - Account age, tweets, followers, verified status        │
│ Weight: 25% of PoH score                                    │
└─────────────────────────────────────────────────────────────┘

Alchemy API:
┌─────────────────────────────────────────────────────────────┐
│ Service: onchain_service.py                                 │
│ Endpoints:                                                   │
│   - https://polygon-amoy.g.alchemy.com/v2/{API_KEY}        │
│ Methods:                                                     │
│   - eth_getTransactionCount (tx count)                     │
│   - eth_getBalance (wallet balance)                        │
│   - alchemy_getTokenBalances (token holdings)              │
│ Data Retrieved:                                             │
│   - Transaction history, balances, token holdings          │
│ Weight: 40% of PoH score                                    │
└─────────────────────────────────────────────────────────────┘

Polygon RPC:
┌─────────────────────────────────────────────────────────────┐
│ Service: onchain_analytics.py                               │
│ Endpoint: https://rpc-amoy.polygon.technology               │
│ Methods:                                                     │
│   - eth_call (read contract data)                          │
│   - eth_sendRawTransaction (write to contract)             │
│   - eth_blockNumber (current block)                        │
│ Usage:                                                       │
│   - Query smart contracts                                   │
│   - Send transactions                                       │
│   - Get blockchain state                                    │
└─────────────────────────────────────────────────────────────┘
```

### 2. Internal API Endpoints

```
Public API (External Developers):
┌─────────────────────────────────────────────────────────────┐
│ Base: /api/v1                                                │
│ Authentication: X-API-Key header                            │
│                                                             │
│ POST /proof/generate                                        │
│   - Generate ZK proof for user                             │
│   - Rate limited by tier                                    │
│                                                             │
│ POST /proof/verify                                          │
│   - Verify ZK proof validity                               │
│   - Rate limited by tier                                    │
│                                                             │
│ POST /passport/query                                        │
│   - Query user's credit passport (on-chain)                │
│   - Returns real blockchain data                           │
│   - Rate limited by tier                                    │
│                                                             │
│ GET /health                                                  │
│   - API health check                                        │
│   - No authentication required                             │
└─────────────────────────────────────────────────────────────┘

Management API (Internal):
┌─────────────────────────────────────────────────────────────┐
│ Base: /api                                                   │
│                                                             │
│ POST /api-keys                                              │
│   - Generate new API key                                    │
│   - Params: tier, user_id                                  │
│                                                             │
│ GET /admin/api-keys                                         │
│   - List all API keys                                       │
│   - Admin only (production)                                │
│                                                             │
│ GET /api-keys/{user_id}                                     │
│   - Get user's API keys                                     │
│                                                             │
│ DELETE /api-keys/{api_key}                                  │
│   - Revoke API key                                          │
│                                                             │
│ GET /api-keys/stats/{api_key}                              │
│   - Get usage statistics                                    │
└─────────────────────────────────────────────────────────────┘

Analytics API:
┌─────────────────────────────────────────────────────────────┐
│ Base: /api                                                   │
│                                                             │
│ GET /analytics/onchain                                      │
│   - Real-time on-chain analytics                           │
│   - Data from blockchain                                    │
│                                                             │
│ GET /analytics                                              │
│   - Mock analytics (fallback)                              │
│   - For testing/demo                                        │
└─────────────────────────────────────────────────────────────┘

Oracle API:
┌─────────────────────────────────────────────────────────────┐
│ Base: /api/oracle                                            │
│                                                             │
│ POST /risk-score                                            │
│   - Get AI risk assessment                                  │
│   - Params: wallet_address                                 │
│                                                             │
│ POST /lending-recommendation                                │
│   - Get lending terms recommendation                        │
│   - Params: wallet_address, loan_amount                    │
│                                                             │
│ GET /risk-history/{wallet}                                  │
│   - Get historical risk predictions                        │
│                                                             │
│ GET /stats                                                   │
│   - Oracle statistics                                       │
└─────────────────────────────────────────────────────────────┘
```


---

## 🚀 Future Development Roadmap

### Phase 1: Current State (✅ Complete)
```
✅ Proof of Humanity (PoH)
✅ ZK-ID Badge (Soulbound NFT)
✅ Credit Passport (Dynamic score)
✅ AI Risk Oracle
✅ Proof-as-a-Service API
✅ On-Chain Analytics
✅ API Key Management
```

### Phase 2: Enhanced On-Chain Integration (Next)
```
🔄 Real ZK Proof Generation
   - Integrate with Polygon ID
   - Generate verifiable ZK proofs
   - Store proofs on ProofRegistry contract

🔄 Badge Query (On-Chain)
   - Query SimpleZKBadge contract
   - Get real badge data
   - Verify badge ownership on-chain

🔄 The Graph Integration
   - Deploy subgraph
   - Index badge & passport events
   - Query historical data
   - Real-time event subscriptions

🔄 Cross-Chain Support
   - Deploy to Polygon zkEVM mainnet
   - Support multiple chains
   - Bridge functionality
```

### Phase 3: Advanced Features
```
🔄 Machine Learning Model
   - Train ML model on real data
   - Improve risk prediction accuracy
   - Behavioral pattern analysis
   - Fraud detection

🔄 Reputation DAO
   - Governance token
   - Community voting
   - Dispute resolution
   - Protocol upgrades

🔄 DeFi Integrations
   - Aave integration
   - Compound integration
   - Uniswap integration
   - Custom lending pools

🔄 Social Graph
   - On-chain social connections
   - Trust network analysis
   - Reputation propagation
   - Sybil resistance
```

### Phase 4: Enterprise Features
```
🔄 White-Label Solutions
   - Custom branding
   - Private deployments
   - Dedicated infrastructure

🔄 Advanced Analytics
   - Real-time dashboards
   - Predictive analytics
   - Custom reports
   - Data export

🔄 Compliance Tools
   - KYC integration
   - AML screening
   - Regulatory reporting
   - Audit trails

🔄 SDK & Libraries
   - JavaScript SDK
   - Python SDK
   - Solidity library
   - Mobile SDKs
```

---

## 📊 Performance & Scalability

### Current Capacity
```
Backend:
- API Requests: ~1000 req/sec
- Database: In-memory (dev) / MongoDB (prod)
- Caching: None (to be added)

Blockchain:
- Network: Polygon Amoy (testnet)
- TPS: ~65,000 (Polygon capacity)
- Block Time: ~2 seconds
- Gas Cost: Very low (testnet)

Frontend:
- Framework: React
- Build: Production optimized
- CDN: To be added
- Caching: Browser cache
```

### Scaling Strategy
```
Horizontal Scaling:
- Load balancer (Nginx)
- Multiple backend instances
- Database replication
- Redis caching

Vertical Scaling:
- Increase server resources
- Optimize database queries
- Code optimization
- CDN for static assets

Blockchain Scaling:
- Batch transactions
- Layer 2 solutions
- State channels
- Optimistic rollups
```

---

## 🔐 Security Architecture

### Authentication & Authorization
```
User Authentication:
- Wallet signature verification
- MetaMask integration
- No password required
- Session management

API Authentication:
- API key in header
- Rate limiting per tier
- Usage tracking
- Key revocation

Smart Contract Security:
- Soulbound (non-transferable)
- Access control (Ownable)
- Authorized minters only
- Reentrancy protection
```

### Data Security
```
On-Chain:
- Immutable storage
- Cryptographic proofs
- Public verification
- Transparent audit trail

Off-Chain:
- Encrypted connections (HTTPS)
- Environment variables
- API key hashing
- Input validation

Privacy:
- Zero-knowledge proofs
- No PII stored on-chain
- Optional data disclosure
- User-controlled data
```

---

## 📈 Monitoring & Observability

### Metrics to Track
```
Business Metrics:
- Total users
- Verified users
- Badges minted
- Passports created
- API calls
- Revenue (API subscriptions)

Technical Metrics:
- API response time
- Error rates
- Uptime
- Database performance
- Blockchain sync status
- Gas costs

User Metrics:
- Active users (DAU/MAU)
- Conversion rate
- Retention rate
- Feature usage
- User journey
```

### Logging Strategy
```
Application Logs:
- Backend: Python logging
- Level: INFO, WARNING, ERROR
- Format: JSON structured logs
- Storage: Files / CloudWatch

Blockchain Logs:
- Contract events
- Transaction receipts
- Gas usage
- Failed transactions

API Logs:
- Request/response
- API key usage
- Rate limit hits
- Error tracking
```

---

## ✅ Summary

**Aura Protocol Data Flow** mencakup:

1. **5 Core Features** dengan detailed flow
2. **On-Chain Integration** dengan smart contracts
3. **Data Storage** (on-chain + off-chain)
4. **External Integrations** (GitHub, Twitter, Alchemy)
5. **Internal APIs** (Public + Management)
6. **Future Roadmap** (4 phases)
7. **Performance & Scalability** strategy
8. **Security Architecture**
9. **Monitoring & Observability**

**Dokumen ini adalah blueprint lengkap untuk pengembangan Aura Protocol ke depan!** 🚀

---

**"Universal Trust in a Trustless World"** 🌟
