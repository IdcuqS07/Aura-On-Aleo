#!/bin/bash
cd frontend
yarn start
